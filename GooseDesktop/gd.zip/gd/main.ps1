function startGoose {

Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName PresentationCore

$timeout = 180 # 2 minutes in seconds
$stopTime = (Get-Date).AddSeconds($timeout)

start-process $env:TEMP\gd\GooseDesktop.exe

while (1){
    $Lctrl = [Windows.Input.Keyboard]::IsKeyDown([System.Windows.Input.Key]::'LeftCtrl')
    $Rctrl = [Windows.Input.Keyboard]::IsKeyDown([System.Windows.Input.Key]::RightCtrl)

    if ($Rctrl -and $Lctrl) {powershell $env:TEMP\gd\CloseGoose.bat;exit}
    elseif ((Get-Date) -ge $stopTime) {powershell $env:TEMP\gd\CloseGoose.bat;exit}
    else {continue}
}
}

startGoose

